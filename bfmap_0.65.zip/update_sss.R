#!/usr/bin/env Rscript

# Processing command-line arguments
args = commandArgs(trailingOnly=TRUE)
help_msg = paste("Six arguments must be supplied:",
			"  model-file",
			"  variant-annotation-file",
			"  annotation-name",
			"  category-prob-file",
			"  cumulative-model-prob-cutoff",
			"  output-filename\n",sep="\n")
if (length(args)!=6) {
	stop(help_msg, call.=FALSE)
}
model_file = args[1]
annot_file = args[2]
annot_name = args[3]
cat_prob_file = args[4]
model_prob_cutoff = args[5]
out_file = args[6]
if(!file.exists(model_file)) {
	cat(help_msg)
	stop(paste("Model-file [",model_file,"] does not exist.\n"), call.=FALSE)
}
if(!file.exists(annot_file)) {
	cat(help_msg)
	stop(paste("Variant-annotation-file [",annot_file,"] does not exist.\n"), call.=FALSE)
}
if(!file.exists(cat_prob_file)) {
	cat(help_msg)
	stop(paste("Category-prob-file [",cat_prob_file,"] does not exist.\n"), call.=FALSE)
}
model_prob_cutoff = as.numeric(model_prob_cutoff)
if(is.na(model_prob_cutoff)) {
	cat(help_msg)
	stop("Probability-cutoff must be numeric.\n", call.=FALSE)
}
annot = read.table(annot_file,head=TRUE)
if(!(annot_name %in% colnames(annot))) {
	stop(paste("Annotation [",annot_name,"] is not available in [", annot_file,"].\n"), call.=FALSE)
}
# Completed processing command-line

annot[[annot_name]] = as.factor(annot[[annot_name]])
cat_names = levels(annot[[annot_name]])
levels(annot[[annot_name]])= c(1:length(cat_names))
var2cat = new.env(hash=TRUE)
cats = apply(annot, 1, function(x) var2cat[[x[1]]] = x[annot_name])

cat_prob = read.table(cat_prob_file,head=TRUE)
cat_prob[,1] = as.factor(cat_prob[,1])
if(!all(cat_names == levels(cat_prob[,1]))) {
	stop(paste("Categories in [",cat_prob_file,"] are not exactly the same as in [", annot_file,"].\n"), call.=FALSE)
}
if(any(cat_prob[,2:3]<=0)) {
	stop(paste("Category prob's in [",cat_prob_file,"] must be positive.\n"), call.=FALSE)
}
cat_prob = cat_prob[order(cat_prob[,1]),]
freq = cat_prob[,3]/sum(cat_prob[,3])
par = cat_prob[,2]/sum(cat_prob[,2])

dat = read.table(model_file,stringsAsFactors=FALSE)
pcol = ncol(dat)
dat$V1 = as.factor(dat$V1)
loci = levels(dat$V1)

icutoff = rep(NA,length(loci))
for(i in c(1:length(loci)))
{
	d=dat[dat$V1==loci[i],]
	d=d[order(-d[,pcol]),]
	pcum = cumsum(d[,pcol])
	icutoff[i] = match(TRUE, pcum>model_prob_cutoff)
	if(is.na(icutoff[i])) {icutoff[i] = length(pcum)}
}

cat(paste("Completed reading all data files.\n",
		"The analysis includes ", length(loci), " loci (locus) and ", sum(icutoff)," models.\n",sep=""))

out_dat = c()
out_pip = c()
for(i in c(1:length(loci)))
{
	d=dat[dat$V1==loci[i],]
	d=d[order(-d[,pcol]),]
	d=d[1:icutoff[i],]
#	psum = sum(d[,pcol])
	set = unique(unlist(d[,2:(pcol-2)]))
	set = set[!is.na(set)]
	res=rep(0,nrow(d))
	for(m in c(1:nrow(d)))
	{
		var = d[m,2:(pcol-2)]
		var = var[!is.na(var)]
		pp = prod(par[ as.numeric(unlist(sapply(var, function(x) var2cat[[x]]))) ])
		qp = prod(freq[ as.numeric(unlist(sapply(var, function(x) var2cat[[x]]))) ])
		
		res[m] = d[m,pcol]*pp/qp
	}
	d[,pcol]=res/sum(res)
	pip = new.env(hash=TRUE)
	sapply(set, function(x) pip[[x]] = 0)
	for(m in c(1:nrow(d)))
	{
		var = d[m,2:(pcol-2)]
		var = var[!is.na(var)]
		sapply(var, function(x) pip[[x]] = pip[[x]]+d[m,pcol])
	}
	table_pip = cbind(rep(loci[i],length(set)),set, sapply(set, function(x) pip[[x]]))
	out_dat = rbind(out_dat, d)
	out_pip = rbind(out_pip, table_pip)
	cat(paste("Locus",i,"completed\n"))
}
write.table(out_dat,paste(out_file,"model.txt",sep="."),append=FALSE,sep="\t",row.names=FALSE,col.names=FALSE,quote=FALSE)
colnames(out_pip) = c("locus","variant","pip")
write.table(out_pip,paste(out_file,"pip.txt",sep="."),append=FALSE,sep="\t",row.names=FALSE,quote=FALSE)

