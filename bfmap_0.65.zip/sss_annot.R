#!/usr/bin/env Rscript
library(pracma)

# Processing command-line arguments
args = commandArgs(trailingOnly=TRUE)
help_msg = paste("Six arguments must be supplied:",
			"  model-file",
			"  variant-annotation-file",
			"  annotation-name",
			"  category-prob-file",
			"  cumulative-model-prob-cutoff",
			"  output-filename\n",sep="\n")
if (length(args)!=6) {
	stop(help_msg, call.=FALSE)
}
model_file = args[1]
annot_file = args[2]
annot_name = args[3]
cat_prob_file = args[4]
model_prob_cutoff = args[5]
out_file = args[6]
if(!file.exists(model_file)) {
	cat(help_msg)
	stop(paste("Model-file [",model_file,"] does not exist.\n"), call.=FALSE)
}
if(!file.exists(annot_file)) {
	cat(help_msg)
	stop(paste("Variant-annotation-file [",annot_file,"] does not exist.\n"), call.=FALSE)
}
if(!file.exists(cat_prob_file)) {
	cat(help_msg)
	stop(paste("Category-prob-file [",cat_prob_file,"] does not exist.\n"), call.=FALSE)
}
model_prob_cutoff = as.numeric(model_prob_cutoff)
if(is.na(model_prob_cutoff)) {
	cat(help_msg)
	stop("Probability-cutoff must be numeric.\n", call.=FALSE)
}
annot = read.table(annot_file,head=TRUE)
if(!(annot_name %in% colnames(annot))) {
	stop(paste("Annotation [",annot_name,"] is not available in [", annot_file,"].\n"), call.=FALSE)
}
# Completed processing command-line

annot[[annot_name]] = as.factor(annot[[annot_name]])
cat_names = levels(annot[[annot_name]])
levels(annot[[annot_name]])= c(1:length(cat_names))
var2cat = new.env(hash=TRUE)
cats = apply(annot, 1, function(x) var2cat[[x[1]]] = x[annot_name])

cat_prob = read.table(cat_prob_file,head=TRUE)
cat_prob[,1] = as.factor(cat_prob[,1])
if(!all(cat_names == levels(cat_prob[,1]))) {
	stop(paste("Categories in [",cat_prob_file,"] are not exactly the same as in [", annot_file,"].\n"), call.=FALSE)
}
if(any(cat_prob[,2:3]<=0)) {
	stop(paste("Category prob's in [",cat_prob_file,"] must be positive.\n"), call.=FALSE)
}
cat_prob = cat_prob[order(cat_prob[,1]),]
cat_prob[,3] = cat_prob[,3]/sum(cat_prob[,3])
freq = cat_prob[,3]


dat = read.table(model_file,stringsAsFactors=FALSE)
pcol = ncol(dat)
## This is individual model prob cutoff, not cumulative model prob cutoff.
# dat = dat[which(dat[,pcol]>1e-6),]
dat$V1 = as.factor(dat$V1)
levels(dat$V1)=c(1:length(levels(dat$V1)))
nloci = length(levels(dat$V1))

icutoff = rep(NA,nloci)
for(i in c(1:nloci))
{
	d=dat[dat$V1==i,]
	d=d[order(-d[,pcol]),]
	pcum = cumsum(d[,pcol])
	icutoff[i] = match(TRUE, pcum>model_prob_cutoff)
	if(is.na(icutoff[i])) {icutoff[i] = length(pcum)}
	
#	print(d[c(1,icutoff[i]),pcol])
}
cat(paste("Completed reading all data files.\n",
		"The EM optimization uses ", nloci, " loci (locus) and ", sum(icutoff)," models.\n",sep=""))

a=function(par){
	par <- c(par, 1-sum(par))   # sum(par) = 1
	if(!any(par<0)){
		li=rep(0,nloci)
		for(i in c(1:nloci))
		{
			d=dat[dat$V1==i,]
			d=d[order(-d[,pcol]),]
			d=d[1:icutoff[i],]
			res=rep(0,nrow(d))
			for(m in c(1:nrow(d)))
			{
				var = d[m,2:(pcol-2)]
				var = var[!is.na(var)]
				pp = prod(par[ as.numeric(unlist(sapply(var, function(x) var2cat[[x]]))) ])
				qp = prod(freq[ as.numeric(unlist(sapply(var, function(x) var2cat[[x]]))) ])
				
				res[m] = d[m,pcol]*pp/qp
			}
			li[i]=sum(res)
		}
		ret = sum(log(li))
		print(paste("Current objective =", ret))
		return(ret)
	} else return(-100000)
}

par = cat_prob[1:(nrow(cat_prob)-1),2]/sum(cat_prob[,2])

if(length(par) == 1) {
	result <- optimize(a,c(0,1),maximum=TRUE)
	print(result)
	par=c(result$maximum, 1-result$maximum)
} else {
	result = fminsearch(a, par, minimize=FALSE, dfree=TRUE, tol=1e-4)
	print(result)
	par = result$xval
	par = c(par, 1-sum(par))
}

cat_prob[,2]=par
write.table(cat_prob, file=out_file, row.names=FALSE, quote=FALSE, sep="\t")

